# core/constants.py

# --- BANCO DE DADOS DE ORBITAIS DE VALÊNCIA ---
VALENCE_ORBITALS = {
    # Período 1
    "H": [{"n": 1, "l": 0, "name": "1s"}],
    "He": [{"n": 1, "l": 0, "name": "1s"}],

    # Período 2
    "Li": [{"n": 2, "l": 0, "name": "2s"}],
    "Be": [{"n": 2, "l": 0, "name": "2s"}],
    "B": [{"n": 2, "l": 0, "name": "2s"}, {"n": 2, "l": 1, "name": "2p"}],
    "C": [{"n": 2, "l": 0, "name": "2s"}, {"n": 2, "l": 1, "name": "2p"}],
    "N": [{"n": 2, "l": 0, "name": "2s"}, {"n": 2, "l": 1, "name": "2p"}],
    "O": [{"n": 2, "l": 0, "name": "2s"}, {"n": 2, "l": 1, "name": "2p"}],
    "F": [{"n": 2, "l": 0, "name": "2s"}, {"n": 2, "l": 1, "name": "2p"}],
    "Ne": [{"n": 2, "l": 0, "name": "2s"}, {"n": 2, "l": 1, "name": "2p"}],

    # Período 3
    "Na": [{"n": 3, "l": 0, "name": "3s"}],
    "Mg": [{"n": 3, "l": 0, "name": "3s"}],
    "Al": [{"n": 3, "l": 0, "name": "3s"}, {"n": 3, "l": 1, "name": "3p"}],
    "Si": [{"n": 3, "l": 0, "name": "3s"}, {"n": 3, "l": 1, "name": "3p"}],
    "P": [{"n": 3, "l": 0, "name": "3s"}, {"n": 3, "l": 1, "name": "3p"}],
    "S": [{"n": 3, "l": 0, "name": "3s"}, {"n": 3, "l": 1, "name": "3p"}],
    "Cl": [{"n": 3, "l": 0, "name": "3s"}, {"n": 3, "l": 1, "name": "3p"}],
    "Ar": [{"n": 3, "l": 0, "name": "3s"}, {"n": 3, "l": 1, "name": "3p"}],

    # Período 4
    "K": [{"n": 4, "l": 0, "name": "4s"}],
    "Ca": [{"n": 4, "l": 0, "name": "4s"}],
    "Sc": [{"n": 4, "l": 0, "name": "4s"}, {"n": 3, "l": 2, "name": "3d"}],
    "Ti": [{"n": 4, "l": 0, "name": "4s"}, {"n": 3, "l": 2, "name": "3d"}],
    "V": [{"n": 4, "l": 0, "name": "4s"}, {"n": 3, "l": 2, "name": "3d"}],
    "Cr": [{"n": 4, "l": 0, "name": "4s"}, {"n": 3, "l": 2, "name": "3d"}],
    "Mn": [{"n": 4, "l": 0, "name": "4s"}, {"n": 3, "l": 2, "name": "3d"}],
    "Fe": [{"n": 4, "l": 0, "name": "4s"}, {"n": 3, "l": 2, "name": "3d"}],
    "Co": [{"n": 4, "l": 0, "name": "4s"}, {"n": 3, "l": 2, "name": "3d"}],
    "Ni": [{"n": 4, "l": 0, "name": "4s"}, {"n": 3, "l": 2, "name": "3d"}],
    "Cu": [{"n": 4, "l": 0, "name": "4s"}, {"n": 3, "l": 2, "name": "3d"}],
    "Zn": [{"n": 4, "l": 0, "name": "4s"}, {"n": 3, "l": 2, "name": "3d"}],

    "Ga": [{"n": 4, "l": 0, "name": "4s"}, {"n": 4, "l": 1, "name": "4p"}],
    "Ge": [{"n": 4, "l": 0, "name": "4s"}, {"n": 4, "l": 1, "name": "4p"}],
    "As": [{"n": 4, "l": 0, "name": "4s"}, {"n": 4, "l": 1, "name": "4p"}],
    "Se": [{"n": 4, "l": 0, "name": "4s"}, {"n": 4, "l": 1, "name": "4p"}],
    "Br": [{"n": 4, "l": 0, "name": "4s"}, {"n": 4, "l": 1, "name": "4p"}],
    "Kr": [{"n": 4, "l": 0, "name": "4s"}, {"n": 4, "l": 1, "name": "4p"}],

    # Período 5
    "Rb": [{"n": 5, "l": 0, "name": "5s"}],
    "Sr": [{"n": 5, "l": 0, "name": "5s"}],
    "Y": [{"n": 5, "l": 0, "name": "5s"}, {"n": 4, "l": 2, "name": "4d"}],
    "Zr": [{"n": 5, "l": 0, "name": "5s"}, {"n": 4, "l": 2, "name": "4d"}],
    "Nb": [{"n": 5, "l": 0, "name": "5s"}, {"n": 4, "l": 2, "name": "4d"}],
    "Mo": [{"n": 5, "l": 0, "name": "5s"}, {"n": 4, "l": 2, "name": "4d"}],
    "Tc": [{"n": 5, "l": 0, "name": "5s"}, {"n": 4, "l": 2, "name": "4d"}],
    "Ru": [{"n": 5, "l": 0, "name": "5s"}, {"n": 4, "l": 2, "name": "4d"}],
    "Rh": [{"n": 5, "l": 0, "name": "5s"}, {"n": 4, "l": 2, "name": "4d"}],
    "Pd": [{"n": 5, "l": 0, "name": "5s"}, {"n": 4, "l": 2, "name": "4d"}],
    "Ag": [{"n": 5, "l": 0, "name": "5s"}, {"n": 4, "l": 2, "name": "4d"}],
    "Cd": [{"n": 5, "l": 0, "name": "5s"}, {"n": 4, "l": 2, "name": "4d"}],

    "In": [{"n": 5, "l": 0, "name": "5s"}, {"n": 5, "l": 1, "name": "5p"}],
    "Sn": [{"n": 5, "l": 0, "name": "5s"}, {"n": 5, "l": 1, "name": "5p"}],
    "Sb": [{"n": 5, "l": 0, "name": "5s"}, {"n": 5, "l": 1, "name": "5p"}],
    "Te": [{"n": 5, "l": 0, "name": "5s"}, {"n": 5, "l": 1, "name": "5p"}],
    "I": [{"n": 5, "l": 0, "name": "5s"}, {"n": 5, "l": 1, "name": "5p"}],
    "Xe": [{"n": 5, "l": 0, "name": "5s"}, {"n": 5, "l": 1, "name": "5p"}],

    # Período 6
    "Cs": [{"n": 6, "l": 0, "name": "6s"}],
    "Ba": [{"n": 6, "l": 0, "name": "6s"}],
    # Lantanídeos (com 4f e/ou 5d, 6s)
    "La": [{"n": 6, "l": 0, "name": "6s"}, {"n": 5, "l": 2, "name": "5d"}],
    "Ce": [{"n": 6, "l": 0, "name": "6s"}, {"n": 4, "l": 3, "name": "4f"}, {"n": 5, "l": 2, "name": "5d"}],
    "Pr": [{"n": 6, "l": 0, "name": "6s"}, {"n": 4, "l": 3, "name": "4f"}],
    "Nd": [{"n": 6, "l": 0, "name": "6s"}, {"n": 4, "l": 3, "name": "4f"}],
    "Pm": [{"n": 6, "l": 0, "name": "6s"}, {"n": 4, "l": 3, "name": "4f"}],
    "Sm": [{"n": 6, "l": 0, "name": "6s"}, {"n": 4, "l": 3, "name": "4f"}],
    "Eu": [{"n": 6, "l": 0, "name": "6s"}, {"n": 4, "l": 3, "name": "4f"}],
    "Gd": [{"n": 6, "l": 0, "name": "6s"}, {"n": 4, "l": 3, "name": "4f"}, {"n": 5, "l": 2, "name": "5d"}],
    "Tb": [{"n": 6, "l": 0, "name": "6s"}, {"n": 4, "l": 3, "name": "4f"}],
    "Dy": [{"n": 6, "l": 0, "name": "6s"}, {"n": 4, "l": 3, "name": "4f"}],
    "Ho": [{"n": 6, "l": 0, "name": "6s"}, {"n": 4, "l": 3, "name": "4f"}],
    "Er": [{"n": 6, "l": 0, "name": "6s"}, {"n": 4, "l": 3, "name": "4f"}],
    "Tm": [{"n": 6, "l": 0, "name": "6s"}, {"n": 4, "l": 3, "name": "4f"}],
    "Yb": [{"n": 6, "l": 0, "name": "6s"}, {"n": 4, "l": 3, "name": "4f"}],
    "Lu": [{"n": 6, "l": 0, "name": "6s"}, {"n": 4, "l": 3, "name": "4f"}, {"n": 5, "l": 2, "name": "5d"}],

    # Metais de Transição do Período 6
    "Hf": [{"n": 6, "l": 0, "name": "6s"}, {"n": 5, "l": 2, "name": "5d"}],
    "Ta": [{"n": 6, "l": 0, "name": "6s"}, {"n": 5, "l": 2, "name": "5d"}],
    "W": [{"n": 6, "l": 0, "name": "6s"}, {"n": 5, "l": 2, "name": "5d"}],
    "Re": [{"n": 6, "l": 0, "name": "6s"}, {"n": 5, "l": 2, "name": "5d"}],
    "Os": [{"n": 6, "l": 0, "name": "6s"}, {"n": 5, "l": 2, "name": "5d"}],
    "Ir": [{"n": 6, "l": 0, "name": "6s"}, {"n": 5, "l": 2, "name": "5d"}],
    "Pt": [{"n": 6, "l": 0, "name": "6s"}, {"n": 5, "l": 2, "name": "5d"}],
    "Au": [{"n": 6, "l": 0, "name": "6s"}, {"n": 5, "l": 2, "name": "5d"}],
    "Hg": [{"n": 6, "l": 0, "name": "6s"}, {"n": 5, "l": 2, "name": "5d"}],

    # P-block do Período 6
    "Tl": [{"n": 6, "l": 0, "name": "6s"}, {"n": 6, "l": 1, "name": "6p"}],
    "Pb": [{"n": 6, "l": 0, "name": "6s"}, {"n": 6, "l": 1, "name": "6p"}],
    "Bi": [{"n": 6, "l": 0, "name": "6s"}, {"n": 6, "l": 1, "name": "6p"}],
    "Po": [{"n": 6, "l": 0, "name": "6s"}, {"n": 6, "l": 1, "name": "6p"}],
    "At": [{"n": 6, "l": 0, "name": "6s"}, {"n": 6, "l": 1, "name": "6p"}],
    "Rn": [{"n": 6, "l": 0, "name": "6s"}, {"n": 6, "l": 1, "name": "6p"}],

    # Período 7
    "Fr": [{"n": 7, "l": 0, "name": "7s"}],
    "Ra": [{"n": 7, "l": 0, "name": "7s"}],
    # Actinídeos (com 5f e/ou 6d, 7s)
    "Ac": [{"n": 7, "l": 0, "name": "7s"}, {"n": 6, "l": 2, "name": "6d"}],
    "Th": [{"n": 7, "l": 0, "name": "7s"}, {"n": 6, "l": 2, "name": "6d"}],
    "Pa": [{"n": 7, "l": 0, "name": "7s"}, {"n": 5, "l": 3, "name": "5f"}, {"n": 6, "l": 2, "name": "6d"}],
    "U": [{"n": 7, "l": 0, "name": "7s"}, {"n": 5, "l": 3, "name": "5f"}, {"n": 6, "l": 2, "name": "6d"}],
    "Np": [{"n": 7, "l": 0, "name": "7s"}, {"n": 5, "l": 3, "name": "5f"}, {"n": 6, "l": 2, "name": "6d"}],
    "Pu": [{"n": 7, "l": 0, "name": "7s"}, {"n": 5, "l": 3, "name": "5f"}],
    "Am": [{"n": 7, "l": 0, "name": "7s"}, {"n": 5, "l": 3, "name": "5f"}],
    "Cm": [{"n": 7, "l": 0, "name": "7s"}, {"n": 5, "l": 3, "name": "5f"}, {"n": 6, "l": 2, "name": "6d"}],
    "Bk": [{"n": 7, "l": 0, "name": "7s"}, {"n": 5, "l": 3, "name": "5f"}, {"n": 6, "l": 2, "name": "6d"}],
    "Cf": [{"n": 7, "l": 0, "name": "7s"}, {"n": 5, "l": 3, "name": "5f"}],
    "Es": [{"n": 7, "l": 0, "name": "7s"}, {"n": 5, "l": 3, "name": "5f"}],
    "Fm": [{"n": 7, "l": 0, "name": "7s"}, {"n": 5, "l": 3, "name": "5f"}],
    "Md": [{"n": 7, "l": 0, "name": "7s"}, {"n": 5, "l": 3, "name": "5f"}],
    "No": [{"n": 7, "l": 0, "name": "7s"}, {"n": 5, "l": 3, "name": "5f"}],
    "Lr": [{"n": 7, "l": 0, "name": "7s"}, {"n": 5, "l": 3, "name": "5f"}, {"n": 6, "l": 2, "name": "6d"}],

    # Metais de Transição do Período 7 (elementos superpesados)
    "Rf": [{"n": 7, "l": 0, "name": "7s"}, {"n": 6, "l": 2, "name": "6d"}],
    "Db": [{"n": 7, "l": 0, "name": "7s"}, {"n": 6, "l": 2, "name": "6d"}],
    "Sg": [{"n": 7, "l": 0, "name": "7s"}, {"n": 6, "l": 2, "name": "6d"}],
    "Bh": [{"n": 7, "l": 0, "name": "7s"}, {"n": 6, "l": 2, "name": "6d"}],
    "Hs": [{"n": 7, "l": 0, "name": "7s"}, {"n": 6, "l": 2, "name": "6d"}],
    "Mt": [{"n": 7, "l": 0, "name": "7s"}, {"n": 6, "l": 2, "name": "6d"}],
    "Ds": [{"n": 7, "l": 0, "name": "7s"}, {"n": 6, "l": 2, "name": "6d"}],
    "Rg": [{"n": 7, "l": 0, "name": "7s"}, {"n": 6, "l": 2, "name": "6d"}],
    "Cn": [{"n": 7, "l": 0, "name": "7s"}, {"n": 6, "l": 2, "name": "6d"}],

    # P-block do Período 7 (elementos superpesados)
    "Nh": [{"n": 7, "l": 0, "name": "7s"}, {"n": 7, "l": 1, "name": "7p"}],
    "Fl": [{"n": 7, "l": 0, "name": "7s"}, {"n": 7, "l": 1, "name": "7p"}],
    "Mc": [{"n": 7, "l": 0, "name": "7s"}, {"n": 7, "l": 1, "name": "7p"}], # <-- Adicionado ou Corrigido para Mc
    "Lv": [{"n": 7, "l": 0, "name": "7s"}, {"n": 7, "l": 1, "name": "7p"}],
    "Ts": [{"n": 7, "l": 0, "name": "7s"}, {"n": 7, "l": 1, "name": "7p"}],
    "Og": [{"n": 7, "l": 0, "name": "7s"}, {"n": 7, "l": 1, "name": "7p"}],
}

# Paths for images (assuming they are now in a subfolder named 'assets')
GNC_LOGO_PATH = "assets/gnc(1).png"
UFPI_LOGO_PATH = "assets/ufpi.png"
QRCODE_PATH = "assets/qr(1)(1).png"
