# core/pdos_processor.py
import os
import re
import tkinter as tk
from tkinter import messagebox
from .constants import VALENCE_ORBITALS

def l_to_orbital_letter(l_value):
    """Converte o número quântico azimutal (l) para a letra do orbital (s, p, d, f)."""
    if l_value == 0:
        return "s"
    elif l_value == 1:
        return "p"
    elif l_value == 2:
        return "d"
    elif l_value == 3:
        return "f"
    return str(l_value)

def parse_quoted_value(line, nline=0, is_int=True):
    """
    Extrai um valor entre aspas em uma linha.
    Corresponde a iquoted e squoted do Fortran.
    """
    match = re.search(r'="([^"]*)"', line)
    if match:
        value_str = match.group(1).strip()
        if is_int:
            try:
                return int(value_str)
            except ValueError:
                raise ValueError(f"Erro na linha {nline}: Não foi possível converter '{value_str}' para inteiro.")
        else:
            return value_str
    else:
        match_alt = re.search(r'"([^"]*)"', line)
        if match_alt:
            value_str = match_alt.group(1).strip()
            if is_int:
                try:
                    return int(value_str)
                except ValueError:
                    raise ValueError(f"Erro na linha {nline}: Não foi possível converter '{value_str}' para inteiro (formato alternativo).")
            else:
                return value_str
        raise ValueError(f"Erro na linha {nline}: Não foi possível encontrar valor entre aspas na linha: {line.strip()}")

def parse_tagged_value(line, llabel, rlabel, is_float=False):
    """
    Extrai um valor entre tags de abertura e fechamento.
    Corresponde a iparsed e dparsed do Fortran.
    """
    pattern = re.escape(llabel) + r'(.*?)' + re.escape(rlabel)
    match = re.search(pattern, line)
    if match:
        value_str = match.group(1).strip()
        try:
            if is_float:
                return float(value_str)
            else:
                return int(value_str)
        except ValueError:
            raise ValueError(f"Erro: Não foi possível converter '{value_str}' para {'float' if is_float else 'inteiro'} entre '{llabel}' e '{rlabel}'.")
    else:
        raise ValueError(f"Erro: Tags '{llabel}' e '{rlabel}' não encontradas na linha: {line.strip()}")

def process_pdos_file(input_filepath, output_filepath, selected_atom_type, n_ref, l_ref, m_ref, log_widget):
    """
    Implementa a lógica principal do programa fmPDOS.
    input_filepath: Caminho para o arquivo PDOS de entrada.
    output_filepath: Caminho para o arquivo de saída.
    selected_atom_type: Pode ser um índice de átomo (int) ou um símbolo de espécie (str).
    n_ref, l_ref, m_ref: Números quânticos para seleção de orbitais.
    log_widget: Widget de texto para exibir mensagens de log.
    """
    def log_message(message, level="info"):
        log_widget.insert(tk.END, message + "\n")
        log_widget.see(tk.END) # Auto-scroll
        if level == "error":
            messagebox.showerror("Erro de Processamento", message)
        elif level == "warn":
            messagebox.showwarning("Aviso de Processamento", message)

    log_message(f"\nProcessando arquivo PDOS: '{input_filepath}'")
    log_message(f"Saída para: '{output_filepath}'")
    
    # Parâmetros de seleção
    mode = 0 # 0: nenhum selecionado, 1: por índice, 2: por espécie
    if isinstance(selected_atom_type, int):
        mode = 1
        ind_ref = selected_atom_type
        species_ref = ""
        selection_header = f"#  summed up for atom index {ind_ref:>5}"
    elif isinstance(selected_atom_type, str):
        mode = 2
        ind_ref = 0
        species_ref = selected_atom_type.strip().upper()
        selection_header = f"#  summed up over atom species:  {species_ref}"
    else:
        log_message("Erro: Tipo de seleção de átomo inválido. Use int para índice ou str para espécie.", "error")
        return False

    nmax = 10000 
    ene = []
    dos = [] 
    for _ in range(nmax):
        dos.append([0.0, 0.0, 0.0, 0.0])

    nptdef = False
    isferm = False
    efermi = 0.0
    nspin = 0
    norbs = 0
    npts = 0
    nene = 0

    ene_fo = False
    addos = False

    atind = 0
    chlab = ""
    n, l, m, zeta = 0, 0, 0, 0
    polar = "false"
    
    line_count = 0

    try:
        with open(input_filepath, 'r') as f_in:
            for line_count, line in enumerate(f_in, 1):
                s_line = line.strip()

                if s_line.startswith('<pdos>'):
                    continue
                elif s_line.startswith('<nspin>'):
                    nspin = parse_tagged_value(s_line, '<nspin>', '</nspin>')
                    if nspin == 8:
                        log_message("Aviso: nspin=8 detectado, mudando para nspin=4 (conforme fmPDOS original).", "warn")
                        nspin = 4
                    if nspin > 2 and len(dos[0]) < nspin:
                        for i in range(nmax):
                            dos[i].extend([0.0] * (nspin - len(dos[0])))
                elif s_line.startswith('<norbitals>'):
                    norbs = parse_tagged_value(s_line, '<norbitals>', '</norbitals>')
                elif s_line.startswith('<fermi_energy'):
                    efermi = parse_tagged_value(s_line, '<fermi_energy units="eV">', '</fermi_energy>', is_float=True)
                    isferm = True
                elif s_line.startswith('<npoints>'):
                    npts = parse_tagged_value(s_line, '<npoints>', '</npoints>')
                    nptdef = True
                elif s_line.startswith('<energy_values'):
                    ene_fo = True
                    nene = 0
                    ene = []
                elif s_line.startswith('</energy_values>'):
                    ene_fo = False
                    if nptdef and nene != npts:
                        log_message(f"Erro: Número de pontos de energia lidos ({nene}) difere do esperado ({npts}) na linha {line_count}.", "error")
                        return False
                    if nene > nmax:
                        log_message(f"Erro: Número de pontos de energia ({nene}) excede o máximo permitido ({nmax}). Aumente nmax.", "error")
                        return False
                elif s_line.startswith('<orbital'):
                    addos = False
                    atind = 0; chlab = ""; n = 0; l = -1; m = 9; zeta = 0; polar = "false"
                elif s_line.startswith('index='):
                    index = parse_quoted_value(s_line, line_count, is_int=True)
                elif s_line.startswith('atom_index='):
                    atind = parse_quoted_value(s_line, line_count, is_int=True)
                    if mode == 1 and (atind == ind_ref or ind_ref == 0):
                        addos = True
                elif s_line.startswith('species='):
                    chlab = parse_quoted_value(s_line, line_count, is_int=False)
                    if mode == 2 and (chlab.upper() == species_ref or species_ref == "0"):
                        addos = True
                elif s_line.startswith('Z='):
                    zvalue = parse_quoted_value(s_line, line_count, is_int=True)
                elif s_line.startswith('position='):
                    pass
                elif s_line.startswith('n='):
                    n = parse_quoted_value(s_line, line_count, is_int=True)
                    if n_ref != 0 and n != n_ref:
                        addos = False
                elif s_line.startswith('l='):
                    l = parse_quoted_value(s_line, line_count, is_int=True)
                    if l_ref != -1 and l != l_ref:
                        addos = False
                elif s_line.startswith('m='):
                    m = parse_quoted_value(s_line, line_count, is_int=True)
                    if m_ref != 9 and m != m_ref:
                        addos = False
                elif s_line.startswith('z='):
                    zeta = parse_quoted_value(s_line, line_count, is_int=True)
                elif s_line.startswith('P='):
                    polar = parse_quoted_value(s_line, line_count, is_int=False)
                    if polar.lower() == 'true':
                        addos = False
                elif s_line == '>':
                    pass
                elif s_line.startswith('<data>'):
                    if nene == 0:
                        log_message(f"Erro: <data> encontrada antes de <energy_values> ou energy_values vazio na linha {line_count}.", "error")
                        return False

                    for it in range(nene):
                        try:
                            data_line = next(f_in).strip()
                            line_count += 1
                            dos1_values = list(map(float, data_line.split()))
                        except (StopIteration, ValueError):
                            log_message(f"Erro: Falha ao ler dados numéricos de DOS na linha {line_count}: '{data_line if 'data_line' in locals() else 'Fim de arquivo inesperado'}'", "error")
                            return False

                        if addos:
                            for ispin_idx in range(nspin):
                                if ispin_idx < len(dos1_values):
                                    dos[it][ispin_idx] += dos1_values[ispin_idx]
                            
                    dtail = next(f_in).strip()
                    line_count += 1
                    if dtail != '</data>':
                        log_message(f"Erro: Descasamento de dados na linha {line_count}: esperava '</data>', leu '{dtail}'", "error")
                        return False
                elif s_line.startswith('</orbital>'):
                    continue
                elif s_line.startswith('</pdos>'):
                    break
                elif ene_fo:
                    try:
                        energy_val = float(s_line)
                        ene.append(energy_val)
                        nene += 1
                    except ValueError:
                        log_message(f"Erro na linha {line_count}: Esperava valor de energia, leu '{s_line}'", "error")
                        return False
                else:
                    log_message(f"Aviso: Identificador desconhecido no arquivo PDOS, linha {line_count}: {s_line}", "warn")
                    
    except FileNotFoundError:
        log_message(f"Erro: O arquivo de entrada '{input_filepath}' não foi encontrado.", "error")
        return False
    except ValueError as ve:
        log_message(f"Erro de parsing na linha {line_count}: {ve}", "error")
        return False
    except Exception as e:
        log_message(f"Ocorreu um erro inesperado ao ler o arquivo PDOS na linha {line_count}: {e}", "error")
        return False

    try:
        with open(output_filepath, 'w') as f_out:
            f_out.write("#\n")
            f_out.write(f"#  partial DOS extracted from file  {os.path.basename(input_filepath):<60}\n")
            f_out.write(selection_header + "\n")
            f_out.write(f"#  selecting orbital keys  n={n_ref:2}, l={l_ref:2}, m={m_ref:2}\n")
            f_out.write(f"#  The summation is over all zetas (see z= below),\n")
            f_out.write(f"#  neglecting polarisation orbitals (retain orbitals with P=\"false\" only)\n")
            f_out.write("#\n")

            if isferm:
                f_out.write(f"#\n#  Fermi energy :{efermi:13.8f}  eV\n")
            
            f_out.write("#\n")
            spin_headers = ["", "spin 1", "spin 2", "spin 3", "spin 4"]
            header_line = "#    Energy"
            for s in range(1, nspin + 1):
                header_line += f"{spin_headers[s]:>15}"
            f_out.write(header_line + "\n")
            f_out.write("#\n")

            for it in range(nene):
                line_data = f"{ene[it]:13.7f}"
                for ispin_idx in range(nspin):
                    line_data += f"{dos[it][ispin_idx]:15.8f}"
                f_out.write(line_data + "\n")
        log_message(f"Processamento de '{input_filepath}' concluído. Resultado salvo em '{output_filepath}'.")
        return True

    except Exception as e:
        log_message(f"Erro ao escrever o arquivo de saída '{output_filepath}': {e}", "error")
        return False

# NOVA FUNÇÃO: Extrair elementos de um arquivo FDF
def extract_elements_from_fdf(fdf_filepath):
    """
    Lê um arquivo .fdf e tenta extrair os símbolos dos elementos químicos presentes.
    Procura por linhas que começam com 'label' (dentro de blocos de espécies) ou
    por nomes de espécies em blocos como ChemicalSpeciesLabel.
    Retorna uma lista de strings com os símbolos dos elementos.
    """
    elements = set() # Usar um set para evitar duplicatas
    try:
        with open(fdf_filepath, 'r') as f:
            lines = f.readlines()
            
            in_species_block = False
            for line in lines:
                s_line = line.strip()

                if s_line.lower().startswith('%block chemicalspecieslabel'):
                    in_species_block = True
                    continue
                elif s_line.lower().startswith('%endblock chemicalspecieslabel'):
                    in_species_block = False
                    continue

                if in_species_block:
                    parts = s_line.split()
                    # A linha esperada é geralmente "ID Z_val Symbol" e.g., "1 6 C"
                    # Ou "Symbol Z_val ID"
                    if len(parts) >= 3 and parts[2].isalpha(): # Tenta pegar o terceiro token se for uma letra
                        potential_symbol = parts[2].strip()
                        if potential_symbol in VALENCE_ORBITALS:
                            elements.add(potential_symbol)
                    elif len(parts) >= 2 and parts[1].isalpha(): # Tenta pegar o segundo token se for uma letra
                        potential_symbol = parts[1].strip()
                        if potential_symbol in VALENCE_ORBITALS:
                            elements.add(potential_symbol)
                        
                # Tentativa mais genérica de pegar elementos de linhas de coordenadas atômicas
                # Ex: Si  1.0   0.0   0.0   -0.5
                match_coord = re.match(r'^\s*([A-Za-z]{1,3})\s+\S+', s_line)
                if match_coord:
                    element_symbol = match_coord.group(1).strip()
                    if element_symbol in VALENCE_ORBITALS: # Só adiciona se for um elemento conhecido
                         elements.add(element_symbol)

    except FileNotFoundError:
        return []
    except Exception as e:
        # Importante: log_widget não está disponível aqui, então printamos no console.
        # Em um app real, você pode querer um logger global ou retornar um erro.
        print(f"Erro ao ler arquivo FDF: {e}")
        return []

    return sorted(list(elements)) # Retorna uma lista ordenada

def run_python_projected_dos(input_pdos_file, selected_elements, output_folder_name, log_widget):
    """
    Executa a lógica de PDOS projetado em Python.
    output_folder_name: Nome da pasta onde os resultados serão salvos.
    """
    log_widget.insert(tk.END, f"\nIniciando a extração de PDOS projetado para {input_pdos_file}...\n")

    # Usa o nome da pasta fornecido pelo usuário
    output_dir = output_folder_name
    os.makedirs(output_dir, exist_ok=True) # Cria a pasta se não existir

    all_success = True
    for element_symbol in selected_elements:
        element_symbol_upper = element_symbol.strip().upper()
        if element_symbol_upper not in VALENCE_ORBITALS:
            log_widget.insert(tk.END, f"Aviso: Elemento '{element_symbol_upper}' não encontrado no banco de dados de orbitais de valência. Ignorando.\n")
            continue

        orbitals = VALENCE_ORBITALS[element_symbol_upper]
        log_widget.insert(tk.END, f"\nProcessando elemento: {element_symbol_upper}\n")
        for orbital_info in orbitals:
            n_val = orbital_info["n"]
            l_val = orbital_info["l"]
            orbital_letter = l_to_orbital_letter(l_val)
            m_val = 9

            output_filename = f"{element_symbol_upper}_{n_val}{orbital_letter}_pdos.dat"
            output_filepath = os.path.join(output_dir, output_filename)

            log_widget.insert(tk.END, f"  Extraindo {element_symbol_upper} {n_val}{orbital_letter} para '{output_filepath}'...\n")

            success = process_pdos_file(
                input_pdos_file,
                output_filepath,
                element_symbol_upper,
                n_val,
                l_val,
                m_val,
                log_widget
            )
            if not success:
                all_success = False
                log_widget.insert(tk.END, f"  Falha para {element_symbol_upper} {n_val}{orbital_letter}. Verifique o log acima.\n")

    if all_success:
        log_widget.insert(tk.END, "\nExtração de PDOS projetado concluída com sucesso para todos os itens selecionados.\n")
    else:
        log_widget.insert(tk.END, "\nExtração de PDOS projetado concluída, mas com falhas para alguns itens.\n")
    log_widget.see(tk.END)
    return all_success

def run_python_total_dos(input_pdos_file, output_folder_name, log_widget):
    """
    Executa a lógica de Densidade de Estados Total (TDOS) em Python.
    output_folder_name: Nome da pasta onde os resultados serão salvos.
    """
    log_widget.insert(tk.END, f"\nIniciando a extração da Densidade de Estados Total para {input_pdos_file}...\n")

    # Usa o nome da pasta fornecido pelo usuário
    output_dir = output_folder_name
    os.makedirs(output_dir, exist_ok=True) # Cria a pasta se não existir
    output_filepath = os.path.join(output_dir, "TOTAL_DOS.dat")

    log_widget.insert(tk.END, f"  Extraindo TOTAL_DOS para '{output_filepath}'...\n")

    success = process_pdos_file(
        input_pdos_file,
        output_filepath,
        0,
        0,
        -1,
        9,
        log_widget
    )

    if success:
        log_widget.insert(tk.END, f"  Concluído: TOTAL_DOS.dat gerado em '{output_filepath}'.\n")
    else:
        log_widget.insert(tk.END, f"  Falha ao gerar TOTAL_DOS.dat. Verifique o log acima.\n")
    log_widget.see(tk.END)
    return success
