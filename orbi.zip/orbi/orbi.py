# main_app.py
import sys
import os

# Adiciona o diretório raiz do projeto ao PATH do Python
# Isso é crucial para que os módulos internos (core, gui) possam ser importados
script_dir = os.path.dirname(__file__)
if script_dir not in sys.path:
    sys.path.append(script_dir)

from gui.main_window import MainWindow

if __name__ == "__main__":
    app = MainWindow()
    app.mainloop()
