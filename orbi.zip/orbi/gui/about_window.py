# gui/about_window.py
import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import os
from core.constants import QRCODE_PATH # Import path from constants

class AboutWindow(tk.Toplevel):
    def __init__(self, master=None):
        super().__init__(master)
        self.title("Sobre o Programa")
        self.geometry("500x600")
        self.configure(bg="#F0F0F0")
        self.resizable(False, False)

        # Center the Toplevel window relative to the main window
        self.update_idletasks()
        if master: # Ensure master exists
            x = master.winfo_x() + (master.winfo_width() // 2) - (self.winfo_width() // 2)
            y = master.winfo_y() + (master.winfo_height() // 2) - (self.winfo_height() // 2)
            self.geometry(f"+{x}+{y}")
        
        self.images_tk = {} # To keep PhotoImage references

        self.create_widgets()

    def load_image_for_tkinter(self, path, size=None):
        """
        Carrega uma imagem usando Pillow e a prepara para o Tkinter.
        Retorna PhotoImage ou None se houver erro.
        """
        # Constrói o caminho absoluto para a imagem, partindo do diretório do main_app.py
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        absolute_path = os.path.join(base_dir, path)
        
        if not os.path.exists(absolute_path):
            return None

        try:
            img = Image.open(absolute_path) # Usa o caminho absoluto
            if size:
                img = img.resize(size, Image.LANCZOS)
            photo_image = ImageTk.PhotoImage(img)
            self.images_tk[path] = photo_image # Armazena com o caminho original para referência
            return photo_image
        except Exception as e:
            messagebox.showerror("Erro de Imagem", f"Não foi possível carregar a imagem '{absolute_path}': {e}")
            return None

    def create_widgets(self):
        about_font_text = ("Times New Roman", 10)
        about_font_email = ("Times New Roman", 10, "underline")

        text_content = """Sobre o programa

O software foi criado por Henrique Lago, físico formado pela Universidade Federal do Piauí (UFPI), durante sua Iniciação Científica Voluntária, sob orientação do Professor Dr. Ramon Sampaio Ferreira. O desenvolvimento ocorreu no âmbito do Grupo de Nanofísica Computacional (GNC) da UFPI.


O programa automatiza a projeção de estados obtidos por meio de cálculos de DFT, utilizando o utilitário fmpdos. Ele implementa toda a lógica do fmpdos e executa, de forma automatizada, a projeção de todos os orbitais, organizando os resultados separadamente para cada orbital projetado.

Conheça o Grupo de Nanofísica Computacional (GNC) escaneando o QR Code abaixo:
"""
        tk.Label(self, text=text_content, font=about_font_text, wraplength=450, justify=tk.LEFT, bg="#F0F0F0").pack(padx=20, pady=10)

        # Use the constant for QR Code path
        self.qrcode_tk = self.load_image_for_tkinter(QRCODE_PATH, (200, 200)) 
        if self.qrcode_tk:
            tk.Label(self, image=self.qrcode_tk, bg="#F0F0F0").pack(pady=5)
        else:
            tk.Label(self, text=f"[Arquivo {os.path.basename(QRCODE_PATH)} não encontrado]", font=about_font_text, fg="red", bg="#F0F0F0").pack(pady=5)
            messagebox.showwarning("QR Code Ausente", f"O arquivo '{os.path.basename(QRCODE_PATH)}' não foi encontrado ou não pôde ser carregado na pasta esperada (assets/).")

        tk.Label(self, text="e-mail: henrique.liberato@ufpi.edu.br", font=about_font_email, bg="#F0F0F0").pack(pady=10)
