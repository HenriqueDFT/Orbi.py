# gui/main_window.py
import tkinter as tk
from tkinter import messagebox, filedialog, scrolledtext
from PIL import Image, ImageTk
import os

from core.pdos_processor import run_python_projected_dos, run_python_total_dos, extract_elements_from_fdf
from core.constants import VALENCE_ORBITALS, GNC_LOGO_PATH, UFPI_LOGO_PATH
from gui.about_window import AboutWindow

class MainWindow(tk.Tk):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.title("Automatizador de PDOS - GNC/UFPI")
        self.geometry("900x700")
        self.configure(bg="#E0E0E0")

        self.images_tk = {} # Crucial for PhotoImage references

        self.create_widgets()

    def load_image_for_tkinter(self, path, size=None):
        """
        Carrega uma imagem usando Pillow e a prepara para o Tkinter.
        Retorna PhotoImage ou None se houver erro.
        """
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        absolute_path = os.path.join(base_dir, path)
        
        if not os.path.exists(absolute_path):
            return None

        try:
            img = Image.open(absolute_path)
            if size:
                img = img.resize(size, Image.LANCZOS)
            photo_image = ImageTk.PhotoImage(img)
            self.images_tk[path] = photo_image
            return photo_image
        except Exception as e:
            messagebox.showerror("Erro de Imagem", f"Não foi possível carregar a imagem '{absolute_path}': {e}")
            return None

    def create_widgets(self):
        # --- Top Frame for Logos ---
        top_frame = tk.Frame(self, bg="#E0E0E0")
        top_frame.pack(fill="x", pady=10)

        self.gnc_logo_tk = self.load_image_for_tkinter(GNC_LOGO_PATH, (100, 100))
        if self.gnc_logo_tk:
            tk.Label(top_frame, image=self.gnc_logo_tk, bg="#E0E0E0").pack(side="left", padx=20)
        else:
            tk.Label(top_frame, text="[Logo GNC não encontrada]", fg="red", bg="#E0E0E0").pack(side="left", padx=20)

        tk.Label(top_frame, text="Automatizador de PDOS - GNC/UFPI", font=("Helvetica", 18, "bold"), bg="#E0E0E0", fg="#333333").pack(side="left", expand=True)

        self.ufpi_logo_tk = self.load_image_for_tkinter(UFPI_LOGO_PATH, (100, 100))
        if self.ufpi_logo_tk:
            tk.Label(top_frame, image=self.ufpi_logo_tk, bg="#E0E0E0").pack(side="right", padx=20)
        else:
            tk.Label(top_frame, text="[Logo UFPI não encontrada]", fg="red", bg="#E0E0E0").pack(side="right", padx=20)

        # --- Main Content Frame ---
        main_content_frame = tk.Frame(self, bg="#F5F5F5", bd=2, relief="groove", padx=15, pady=15)
        main_content_frame.pack(padx=20, pady=10, fill="both", expand=True)

        # --- Input Section ---
        input_frame = tk.LabelFrame(main_content_frame, text="Configurações de Entrada", font=("Helvetica", 12, "bold"), bg="#F5F5F5", padx=10, pady=10)
        input_frame.pack(fill="x", pady=10)

        tk.Label(input_frame, text="Arquivo PDOS:", bg="#F5F5F5").grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.pdos_file_entry = tk.Entry(input_frame, width=50)
        self.pdos_file_entry.grid(row=0, column=1, padx=5, pady=5, sticky="ew")
        tk.Button(input_frame, text="Procurar...", command=self.browse_pdos_file).grid(row=0, column=2, padx=5, pady=5)

        tk.Label(input_frame, text="Elementos (ex: C,O,Fe ou 'all'):", bg="#F5F5F5").grid(row=1, column=0, padx=5, pady=5, sticky="w")
        self.elements_entry = tk.Entry(input_frame, width=50)
        self.elements_entry.grid(row=1, column=1, padx=5, pady=5, sticky="ew")

        # Botão para carregar elementos do FDF
        self.load_fdf_button = tk.Button(input_frame, text="Carregar Elementos do FDF", command=self.load_elements_from_fdf)
        self.load_fdf_button.grid(row=1, column=2, padx=5, pady=5)

        # Campo para nomear a pasta de resultados
        tk.Label(input_frame, text="Nome da Pasta de Saída:", bg="#F5F5F5").grid(row=3, column=0, padx=5, pady=5, sticky="w")
        self.output_folder_entry = tk.Entry(input_frame, width=50)
        self.output_folder_entry.grid(row=3, column=1, padx=5, pady=5, sticky="ew")
        self.output_folder_entry.insert(0, "extracted_pdos") # Sugere um nome padrão

        # Display available elements
        available_elements_str = ", ".join(sorted(VALENCE_ORBITALS.keys()))
        tk.Label(input_frame, text=f"Disponíveis: {available_elements_str}", font=("Helvetica", 9, "italic"), fg="gray", bg="#F5F5F5", wraplength=400, justify=tk.LEFT).grid(row=2, column=0, columnspan=3, padx=5, pady=2, sticky="w")

        input_frame.grid_columnconfigure(1, weight=1)

        # --- Action Buttons ---
        button_frame = tk.Frame(main_content_frame, bg="#F5F5F5")
        button_frame.pack(pady=10)

        tk.Button(button_frame, text="Extrair PDOS Projetado", command=self.run_projected_dos_action, font=("Helvetica", 10, "bold"), bg="#4CAF50", fg="white", padx=10, pady=5).pack(side="left", padx=10)
        tk.Button(button_frame, text="Extrair TDOS", command=self.run_total_dos_action, font=("Helvetica", 10, "bold"), bg="#2196F3", fg="white", padx=10, pady=5).pack(side="left", padx=10)
        
        # NOVO: Botão "Sobre" adicionado ao lado dos botões de ação
        tk.Button(button_frame, text="Sobre", command=self.show_about_info, font=("Helvetica", 10), bg="#FFC107", fg="#333333", padx=10, pady=5).pack(side="left", padx=10)


        # --- Output Log ---
        log_frame = tk.LabelFrame(main_content_frame, text="Log de Processamento", font=("Helvetica", 12, "bold"), bg="#F5F5F5", padx=10, pady=10)
        log_frame.pack(fill="both", expand=True, pady=10)

        self.log_text = scrolledtext.ScrolledText(log_frame, width=80, height=15, state='disabled', wrap='word', font=("Consolas", 9), bg="#FFFFFF", fg="#333333")
        self.log_text.pack(fill="both", expand=True)

        # REMOVIDO: O botão "Sobre" fixo no canto inferior esquerdo não é mais necessário
        # self.about_button = tk.Button(self, text="Sobre", command=self.show_about_info, 
        #                              font=("Helvetica", 10), bg="#FFC107", fg="#333333", padx=10, pady=5)
        # self.about_button.place(relx=0, rely=1, anchor='sw', x=20, y=-20)


    def browse_pdos_file(self):
        file_path = filedialog.askopenfilename(
            title="Selecione o arquivo PDOS",
            filetypes=[("Arquivos PDOS", "*.PDOS"), ("Todos os arquivos", "*.*")]
        )
        if file_path:
            self.pdos_file_entry.delete(0, tk.END)
            self.pdos_file_entry.insert(0, file_path)

    def load_elements_from_fdf(self):
        fdf_file_path = filedialog.askopenfilename(
            title="Selecione o arquivo .fdf",
            filetypes=[("Arquivos FDF", "*.fdf"), ("Todos os arquivos", "*.*")]
        )
        if fdf_file_path:
            self.log_text.config(state='normal')
            self.log_text.insert(tk.END, f"\nTentando extrair elementos de: {fdf_file_path}\n")
            self.log_text.config(state='disabled')
            
            elements = extract_elements_from_fdf(fdf_file_path)
            
            if elements:
                elements_str = ", ".join(elements)
                self.elements_entry.delete(0, tk.END)
                self.elements_entry.insert(0, elements_str)
                self.log_text.config(state='normal')
                self.log_text.insert(tk.END, f"Elementos encontrados e preenchidos: {elements_str}\n")
                self.log_text.config(state='disabled')
            else:
                self.log_text.config(state='normal')
                self.log_text.insert(tk.END, "Nenhum elemento válido (com orbitais definidos) encontrado no arquivo FDF ou erro na leitura.\n")
                self.log_text.config(state='disabled')
                messagebox.showwarning("FDF Vazio", "Não foi possível extrair elementos do arquivo .fdf ou nenhum elemento conhecido foi encontrado.")
        self.log_text.see(tk.END) # Scroll to end of log


    def run_projected_dos_action(self):
        input_file = self.pdos_file_entry.get().strip()
        elements_input = self.elements_entry.get().strip()
        output_folder_name = self.output_folder_entry.get().strip()

        if not input_file:
            messagebox.showerror("Erro de Entrada", "Por favor, selecione o arquivo PDOS.")
            return

        if not os.path.exists(input_file):
            messagebox.showerror("Erro de Arquivo", f"O arquivo '{input_file}' não foi encontrado.")
            return

        if not output_folder_name:
            messagebox.showerror("Erro de Entrada", "Por favor, insira um nome para a pasta de saída dos resultados.")
            return

        selected_elements = []
        if elements_input.lower() == 'all':
            selected_elements = list(VALENCE_ORBITALS.keys())
        elif elements_input:
            selected_elements = [e.strip().upper() for e in elements_input.split(',') if e.strip()]
            if not selected_elements:
                messagebox.showerror("Erro de Entrada", "Nenhum elemento válido foi inserido para PDOS projetado.")
                return
        else:
            messagebox.showerror("Erro de Entrada", "Por favor, insira os elementos para projetar (ex: C,O,Fe) ou 'all'.")
            return

        self.log_text.config(state='normal')
        self.log_text.delete(1.0, tk.END)
        self.log_text.config(state='disabled')

        self.log_text.config(state='normal')
        try:
            success = run_python_projected_dos(input_file, selected_elements, output_folder_name, self.log_text)
            if success:
                messagebox.showinfo("Sucesso", f"Extração de PDOS Projetado concluída! Verifique a pasta '{output_folder_name}'.")
            else:
                messagebox.showwarning("Atenção", "Extração de PDOS Projetado concluída com algumas falhas. Verifique o log.")
        except Exception as e:
            messagebox.showerror("Erro Inesperado", f"Ocorreu um erro inesperado: {e}")
            self.log_text.insert(tk.END, f"\nERRO FATAL: {e}\n")
        finally:
            self.log_text.config(state='disabled')

    def run_total_dos_action(self):
        input_file = self.pdos_file_entry.get().strip()
        output_folder_name = self.output_folder_entry.get().strip()

        if not input_file:
            messagebox.showerror("Erro de Entrada", "Por favor, selecione o arquivo PDOS.")
            return

        if not os.path.exists(input_file):
            messagebox.showerror("Erro de Arquivo", f"O arquivo '{input_file}' não foi encontrado.")
            return
        
        if not output_folder_name:
            messagebox.showerror("Erro de Entrada", "Por favor, insira um nome para a pasta de saída dos resultados.")
            return

        self.log_text.config(state='normal')
        self.log_text.delete(1.0, tk.END)
        self.log_text.config(state='disabled')

        self.log_text.config(state='normal')
        try:
            success = run_python_total_dos(input_file, output_folder_name, self.log_text)
            if success:
                messagebox.showinfo("Sucesso", f"Extração de TDOS concluída! Verifique a pasta '{output_folder_name}'.")
            else:
                messagebox.showwarning("Atenção", "Extração de TDOS concluída com falhas. Verifique o log.")
        except Exception as e:
            messagebox.showerror("Erro Inesperado", f"Ocorreu um erro inesperado: {e}")
            self.log_text.insert(tk.END, f"\nERRO FATAL: {e}\n")
        finally:
            self.log_text.config(state='disabled')

    def show_about_info(self):
        """Exibe o pop-up com as informações 'Sobre o programa'."""
        AboutWindow(self)
